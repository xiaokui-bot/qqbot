# 流式消息合入方案 - 已完成

## 一、方案选择

已采用 **方案 B（重构方案）**：完全采用参考工程的 `onPartialReply` 增量式架构。

## 二、已完成的改动

### 1. `api.ts` 改动

- ✅ 添加 `initApiConfig(options)` 函数，支持运行时配置 `markdownSupport`
- ✅ 添加 `isMarkdownSupport()` 函数，获取当前 markdown 支持状态
- ✅ 添加 `buildStreamBody()` 函数，根据 `markdownSupport` 配置构建消息体
- ✅ 修改 `sendC2CMessage()` 支持 `ApiStreamConfig` 参数，实现流式消息
- ✅ 修改 `sendGroupMessage()` 支持 `ApiStreamConfig` 参数
- ✅ 添加 `sendC2CInputNotify()` 函数，发送输入状态提示
- ✅ 重命名 `StreamConfig` 为 `ApiStreamConfig`，避免与 `types.ts` 冲突

### 2. `outbound.ts` 改动

- ✅ 重写 `StreamSender` 类，采用增量式发送模式
- ✅ 简化 `createStreamSender()` 工厂函数，返回 `StreamSender` 实例
- ✅ 移除旧的 `onStreamStart/onStreamChunk/onStreamEnd` 回调模式
- ✅ 添加 Token 过期自动重试机制

### 3. `gateway.ts` 改动

- ✅ 在 `startGateway()` 开始时调用 `initApiConfig()`，初始化 markdown 配置
- ✅ 在 C2C 消息处理前调用 `sendC2CInputNotify()`，提前发送输入状态
- ✅ 重写流式处理逻辑，采用 `onPartialReply` 增量式发送：
  - 添加 `streamSender` 流式发送器
  - 添加 `streamBuffer`、`lastSentLength` 用于增量计算
  - 添加 `sendingLock` 防止并发发送
  - 添加 `pendingFullText` 在锁定期间积累内容
  - 添加 `keepaliveTimer` 心跳保活机制（8秒间隔）
- ✅ 添加 `handlePartialReply()` 回调处理实时文本
- ✅ 添加 `doStreamSend()` 带锁保护的增量发送函数
- ✅ 添加 `sendStreamChunk()` 发送单个分片
- ✅ 修改 `deliver` 回调，流式模式下不发送文本（通过 `onPartialReply` 发送）
- ✅ 修改 `onError` 回调，正确处理流式中断
- ✅ 修改 `replyOptions`，启用 `onPartialReply` 和 `disableBlockStreaming`

### 4. `types.ts` 改动

- ✅ 添加 `StreamContext` 接口，定义流式发送上下文
- ✅ 简化 `StreamState` 枚举，添加 `STREAMING` 和 `END` 别名

## 三、核心机制说明

### 1. `onPartialReply` 增量式发送

```typescript
// AI 生成过程中，onPartialReply 被实时调用
// payload.text 是累积的全文（不是增量）
const handlePartialReply = async (payload: { text?: string }) => {
  const fullText = payload.text ?? "";
  
  // 更新缓冲区
  streamBuffer = fullText;
  
  // 计算增量
  if (fullText.length > lastSentLength) {
    const increment = fullText.slice(lastSentLength);
    
    // 控制发送频率
    if (!streamStarted || now - lastStreamSendTime >= STREAM_CHUNK_INTERVAL) {
      await streamSender.send(increment, false);
      lastSentLength = fullText.length;
    }
  }
};
```

### 2. 心跳保活机制

```typescript
// 每 8 秒发送空分片，防止 QQ 流式连接超时（10秒限制）
const resetKeepalive = () => {
  if (streamSender && streamStarted && !streamEnded) {
    keepaliveTimer = setTimeout(async () => {
      await streamSender.send("", false);
      resetKeepalive();
    }, STREAM_KEEPALIVE_INTERVAL); // 8000ms
  }
};
```

### 3. 发送锁机制

```typescript
// 防止并发发送导致顺序错乱
const doStreamSend = async (fullText: string, forceEnd: boolean) => {
  if (sendingLock) {
    pendingFullText = fullText; // 积累内容
    return;
  }
  
  sendingLock = true;
  try {
    // 发送增量...
  } finally {
    sendingLock = false;
  }
  
  // 处理积累的内容
  if (pendingFullText) {
    await doStreamSend(pendingFullText, false);
  }
};
```

## 四、验收测试清单

### 功能测试

- [ ] C2C 私聊：发送消息后显示"对方正在输入"
- [ ] C2C 私聊：流式消息正常显示，无超时断开
- [ ] C2C 私聊：流式消息分片顺序正确
- [ ] C2C 私聊：流式消息正常结束（state=10）
- [ ] 群聊：消息正常发送（不支持流式）
- [ ] 频道：消息正常发送（不支持流式）
- [ ] 图片发送：base64 图片正常上传到图床
- [ ] 图片发送：URL 图片正常转发
- [ ] 错误处理：Token 过期自动刷新
- [ ] 错误处理：AI 生成中断时正确发送结束标记

### 性能测试

- [ ] 流式消息延迟 < 1 秒
- [ ] 心跳保活正常工作，无连接断开
- [ ] 并发消息处理正常
- [ ] 长文本（>10000字）正常分片发送

## 五、配置说明

在账户配置中设置 `useMarkdown: true` 启用流式消息：

```json
{
  "qqbot": {
    "accounts": [
      {
        "accountId": "main",
        "appId": "xxx",
        "clientSecret": "xxx",
        "useMarkdown": true
      }
    ]
  }
}
```