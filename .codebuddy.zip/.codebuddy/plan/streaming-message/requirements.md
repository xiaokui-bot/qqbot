# 需求文档：QQ Bot 真流式消息功能 + WebSocket 优化

## 引言

本需求文档描述了为 QQ Bot Channel Plugin 添加真流式消息（Streaming Message）支持的功能，以及优化 WebSocket 连接的心跳（Heartbeat）、会话恢复（Resume）机制和事件异步处理能力。

### 背景

当前 QQ Bot 插件存在以下问题需要解决：

1. **流式消息**：已有基础的流式消息 API 封装（`sendC2CStreamMessage`），但尚未完整集成到 Channel Plugin SDK 的消息发送流程中
2. **WebSocket 心跳机制**：当前实现缺少心跳超时检测，如果服务端长时间不响应 ACK，无法及时感知连接断开
3. **Resume 机制**：需要参考 botgo 官方 SDK 的实现，确保 session 恢复的健壮性
4. **事件处理阻塞**：当前 WebSocket 收到事件后同步处理，会阻塞后续消息接收，需要改为异步处理

### 参考资料

- **Telegram Channel 实现**：了解 Channel Plugin SDK 中流式发送的标准模式
- **QQ 开放平台流式消息 API**：使用 Markdown 消息类型（msg_type=2）+ Stream 字段实现分片发送
- **babyq-exploration 项目**：参考其完整的流式消息发送器实现
- **botgo 官方 SDK**：https://github.com/tencent-connect/botgo - 参考 WebSocket 心跳、resume 机制的最佳实践

### 范围说明

**本版本仅支持 C2C 私聊场景**，不支持群聊（GROUP_AT_MESSAGE）和频道（AT_MESSAGE）场景的流式消息。

---

## 需求

### 需求 1：Channel Plugin 流式发送接口集成

**用户故事：** 作为一名开发者，我希望 QQ Bot Channel Plugin 能够支持 Channel Plugin SDK 的流式发送接口，以便 AI 模型输出可以实时推送给用户。

#### 验收标准

1. WHEN 用户在 C2C 私聊中向机器人发送消息 AND AI 模型支持流式输出 AND 账户配置启用 Markdown THEN 系统 SHALL 使用流式方式发送消息
2. WHEN 流式发送启动 THEN 系统 SHALL 在 channel.ts 的 outbound 配置中提供 `sendStreaming` 方法
3. WHEN 流式发送调用 THEN 系统 SHALL 接收 Channel Plugin SDK 提供的 `stream` 参数（AsyncIterable<StreamChunk>）
4. WHEN 流式发送过程中 THEN 系统 SHALL 将流中的文本内容累积并按分片策略发送到 QQ
5. IF 账户未启用 Markdown（useMarkdown=false）THEN 系统 SHALL 降级为累积所有内容后一次性发送

---

### 需求 2：流式消息发送器（StreamSender）实现

**用户故事：** 作为一名开发者，我希望有一个完善的流式消息发送器，以便可靠地将 AI 流式输出分片发送到 QQ 机器人。

#### 验收标准

1. WHEN 创建 StreamSender 实例 THEN 系统 SHALL 支持配置以下参数：
   - `sliceMaxLen`：单分片最大字符数（默认 500）
   - `sliceMaxBytes`：单分片最大字节数（默认 2000）
   - `firstSendInterval`：首次发送延迟（默认 300ms）
   - `sendInterval`：后续发送间隔（默认 500ms）
   - `blankSendInterval`：保活空分片间隔（默认 10s）
   - `separators`：智能切分分隔符（默认 "。！？.!?\n"）

2. WHEN 累积的消息内容达到 sliceMaxLen 或 sliceMaxBytes 阈值 THEN 系统 SHALL 触发消息发送

3. WHEN 分片内容超过阈值时 THEN 系统 SHALL 智能切分消息：
   - 优先在换行符处切分
   - 其次在句末标点（。！？.!?）处切分
   - 确保括号配对完整
   - 若无合适切分点则强制按字符数切分

4. WHEN 首次发送分片成功 THEN 系统 SHALL 保存返回的 stream_id 用于后续分片

5. WHEN 超过 blankSendInterval 未发送内容 AND 流式未结束 THEN 系统 SHALL 发送空分片保持连接活跃

6. WHEN 流式发送结束 THEN 系统 SHALL 发送 state=10（TextEnd）的结束分片

7. IF 发送过程中发生错误 THEN 系统 SHALL 记录错误日志并尝试继续发送剩余内容

---

### 需求 3：C2C 私聊场景支持

**用户故事：** 作为一名用户，我希望在 C2C 私聊中能够获得流式响应体验。

#### 验收标准

1. WHEN 在 C2C 私聊场景（C2C_MESSAGE_CREATE）THEN 系统 SHALL 使用 `/v2/users/{openid}/messages` 接口发送流式 Markdown 消息

2. WHEN 账户配置启用 Markdown 且为 C2C 场景 THEN 系统 SHALL 自动使用流式发送模式

3. IF 账户未启用 Markdown THEN 系统 SHALL 降级为累积内容后一次性发送普通文本消息

---

### 需求 4：Token 和消息序号管理

**用户故事：** 作为一名开发者，我希望流式发送过程中能正确管理 AccessToken 和消息序号，以便消息能够可靠发送。

#### 验收标准

1. WHEN AccessToken 过期（401 错误）THEN 系统 SHALL 自动刷新 Token 并重试发送

2. WHEN 发送流式分片 THEN 系统 SHALL 自动管理 msg_seq 递增，确保同一条用户消息的多次回复 seq 不重复

3. WHEN 流式发送中需要 msg_id（被动回复）THEN 系统 SHALL 从原始消息中获取并传递给 API

4. IF EventID 可用 THEN 系统 SHALL 优先使用 EventID 进行被动回复以获得更好的体验

---

### 需求 5：错误处理与日志

**用户故事：** 作为一名运维人员，我希望流式发送过程中有完善的错误处理和日志记录，以便排查问题。

#### 验收标准

1. WHEN 发送分片成功 THEN 系统 SHALL 记录 debug 级别日志，包含分片序号、内容长度

2. WHEN 发送分片失败 THEN 系统 SHALL 记录 error 级别日志，包含错误详情

3. WHEN 流式发送完成 THEN 系统 SHALL 记录 info 级别日志，包含总分片数、总字符数、耗时

4. IF 发生网络错误 THEN 系统 SHALL 标记强制结束并尝试发送已累积的内容

5. IF 发送空分片（保活）失败 THEN 系统 SHALL 记录警告但不中断流式发送

---

### 需求 6：配置与开关

**用户故事：** 作为一名管理员，我希望能够通过配置控制是否启用流式消息，以便根据实际需求灵活调整。

#### 验收标准

1. WHEN 账户配置 `useMarkdown: true` THEN 系统 SHALL 启用流式消息能力

2. WHEN 账户配置 `useMarkdown: false` 或未配置 THEN 系统 SHALL 使用普通文本消息（非流式）

3. WHEN 提供可选的流式配置参数 THEN 系统 SHALL 支持在账户配置或全局配置中调整流式参数

4. IF 配置中指定了自定义流式参数 THEN 系统 SHALL 覆盖默认值

---

### 需求 7：WebSocket 心跳（Heartbeat）机制优化

**用户故事：** 作为一名运维人员，我希望 WebSocket 连接能够及时检测心跳超时，以便在连接异常时快速恢复。

#### 验收标准

1. WHEN 收到 Hello 包（op=10）THEN 系统 SHALL 按服务端返回的 `heartbeat_interval` 启动心跳定时器

2. WHEN 发送心跳包（op=1）THEN 系统 SHALL 记录发送时间并等待 Heartbeat ACK（op=11）

3. WHEN 收到 Heartbeat ACK THEN 系统 SHALL 重置心跳超时计时器

4. IF 连续 N 次（默认 2 次）发送心跳未收到 ACK THEN 系统 SHALL 主动关闭连接并触发重连
   - 参考 botgo SDK：如果发送心跳后在下一个心跳间隔内未收到 ACK，认为连接已断开

5. WHEN 心跳超时触发重连 THEN 系统 SHALL 保留 session_id 和 lastSeq，尝试 Resume 恢复会话

6. IF 心跳间隔小于 30 秒 THEN 系统 SHALL 使用服务端返回的间隔；IF 大于 30 秒 THEN 系统 SHALL 使用 30 秒作为最大间隔

---

### 需求 8：WebSocket Resume 机制优化

**用户故事：** 作为一名开发者，我希望 WebSocket 断线重连时能够正确恢复会话，避免丢失消息。

#### 验收标准

1. WHEN 收到 READY 事件 THEN 系统 SHALL 保存 session_id 和 gateway resume URL（如有）

2. WHEN 连接断开且 session_id 有效 THEN 系统 SHALL 优先尝试 Resume（op=6）而非重新 Identify

3. WHEN Resume 成功（收到 RESUMED 事件）THEN 系统 SHALL 继续使用当前 session，不重置 lastSeq

4. WHEN Resume 失败（收到 Invalid Session，op=9，d=false）THEN 系统 SHALL：
   - 清除 session_id 和 lastSeq
   - 发起新的 Identify 流程

5. WHEN 收到服务端 Reconnect 指令（op=7）THEN 系统 SHALL：
   - 保留 session_id 和 lastSeq
   - 关闭当前连接
   - 立即发起重连并尝试 Resume

6. WHEN 连接关闭码为 4009 THEN 系统 SHALL 保留 session 信息，可以尝试 Resume

7. WHEN 连接关闭码为 4900-4913（内部错误）THEN 系统 SHALL 清除 session 信息，重新 Identify

8. WHEN 连接关闭码为 4914（机器人已下架）或 4915（机器人已封禁）THEN 系统 SHALL 停止重连并记录错误

---

### 需求 9：WebSocket 事件异步处理

**用户故事：** 作为一名开发者，我希望 WebSocket 事件处理不会阻塞消息接收，以便能够及时响应后续事件。

#### 验收标准

1. WHEN 收到 Dispatch 事件（op=0）THEN 系统 SHALL 立即返回（汇报收到），后续处理异步执行

2. WHEN 收到消息事件（C2C_MESSAGE_CREATE）THEN 系统 SHALL：
   - 同步更新 lastSeq（如有）
   - 异步调用 handleMessage 处理消息
   - 不等待 handleMessage 完成即可继续接收下一条消息

3. WHEN 异步处理消息时发生错误 THEN 系统 SHALL 记录错误日志，但不影响 WebSocket 连接

4. WHEN 多条消息并发处理时 THEN 系统 SHALL 确保各消息的回复互不干扰
   - 每条消息有独立的 messageId 和 msg_seq 管理

5. IF 消息处理队列积压超过阈值（可配置，默认 100）THEN 系统 SHALL：
   - 记录警告日志
   - 丢弃最旧的未处理消息
   - 可选：向用户发送"系统繁忙"提示

---

## 技术约束

1. **QQ 开放平台限制**：
   - 流式消息必须使用 Markdown 类型（msg_type=2）
   - 分片大小建议不超过 2000 字节
   - 发送频率建议不低于 500ms 间隔
   - 保活间隔建议不超过 30s

2. **Channel Plugin SDK 约束**：
   - 流式发送接口需符合 SDK 的 `sendStreaming` 签名
   - 需要正确处理 SDK 提供的 `stream` AsyncIterable

3. **场景限制**：
   - 本版本仅支持 C2C 私聊场景
   - 不支持群聊（GROUP_AT_MESSAGE）和频道（AT_MESSAGE）场景
   - 需要确保与现有非流式发送逻辑的兼容

4. **WebSocket 协议约束**（参考 botgo SDK）：
   - op=0 Dispatch：服务端推送消息
   - op=1 Heartbeat：客户端发送心跳
   - op=2 Identify：客户端发送鉴权
   - op=6 Resume：客户端尝试恢复会话
   - op=7 Reconnect：服务端通知客户端重连
   - op=9 Invalid Session：会话失效
   - op=10 Hello：连接建立后服务端发送
   - op=11 Heartbeat ACK：服务端响应心跳

---

## 边界情况

### 流式消息边界情况

1. **空流**：如果 AI 模型流式输出为空，应发送默认提示消息
2. **超长消息**：单条消息超过 10000 字符时，应确保分片正确处理
3. **快速结束**：如果流式输出很快结束（<300ms），首片即尾片的情况需正确处理
4. **并发消息**：同一用户快速发送多条消息时，各流式会话应独立管理

### WebSocket 边界情况

5. **网络抖动**：网络短暂中断后恢复，Resume 应能正常工作
6. **服务端重启**：服务端重启导致 session 失效，应能正确降级到重新 Identify
7. **长时间离线**：session 超时（通常 5 分钟）后重连，Resume 失败应能处理
8. **消息积压**：短时间内收到大量消息，异步处理应能平滑处理

---

## 成功标准

1. C2C 私聊场景下流式消息可正常分片发送，用户可看到"打字机"效果
2. 发送失败时有明确的错误提示和日志
3. 配置变更后无需重启即可生效
4. WebSocket 心跳超时后能在 30 秒内自动恢复连接
5. Resume 机制在 90% 以上的断线场景下能成功恢复会话
6. 事件异步处理后，消息接收延迟降低到 10ms 以内
7. 并发消息处理时，各消息响应互不干扰
