# 实施计划：QQ Bot 真流式消息功能 + WebSocket 优化

## 流式消息功能

- [ ] 1. 实现流式消息发送器（StreamSender）核心类
   - 在 `src/stream-sender.ts` 中创建 `StreamSender` 类
   - 实现分片配置参数：`sliceMaxLen`、`sliceMaxBytes`、`firstSendInterval`、`sendInterval`、`blankSendInterval`、`separators`
   - 实现智能切分逻辑：按换行符、句末标点、括号配对、强制切分等策略
   - 实现 `push(text)`、`done()`、`error(err)` 方法
   - 管理 `stream_id`、分片序号和状态机（首片 state=1、中间 state=0、尾片 state=10）
   - _需求：2.1、2.2、2.3、2.4、2.6_

- [ ] 2. 实现分片发送定时器和保活机制
   - 实现首次发送延迟（firstSendInterval）和后续发送间隔（sendInterval）
   - 实现保活空分片发送（blankSendInterval）
   - 确保分片累积达到阈值时自动触发发送
   - _需求：2.2、2.5_

- [ ] 3. 集成流式发送到 Channel Plugin 的 outbound 配置
   - 在 `src/channel.ts` 的 `outbound` 中添加 `sendStreaming` 方法
   - 接收 SDK 提供的 `stream` 参数（AsyncIterable<StreamChunk>）
   - 边收边调用 `StreamSender.push()` 发送内容
   - 处理 `useMarkdown` 配置开关，降级为非流式发送
   - _需求：1.1、1.2、1.3、1.4、1.5_

- [ ] 4. 完善流式发送的 API 调用封装
   - 确保 `sendC2CStreamMessage` 函数正确处理 `stream` 字段和 `msg_seq`
   - 实现 Token 过期自动刷新（401 重试）
   - 实现 `msg_seq` 自动递增管理
   - _需求：4.1、4.2、4.3、4.4_

- [ ] 5. 添加流式发送日志和错误处理
   - 发送成功记录 debug 日志（分片序号、内容长度）
   - 发送失败记录 error 日志（错误详情）
   - 发送完成记录 info 日志（总分片数、总字符数、耗时）
   - 网络错误时尝试发送已累积内容
   - _需求：5.1、5.2、5.3、5.4、5.5_

- [ ] 6. 添加流式配置项支持
   - 在账户配置中支持可选的流式参数（sliceMaxLen、sendInterval 等）
   - 更新 `types.ts` 中的 `QQBotAccountConfig` 类型定义
   - _需求：6.1、6.2、6.3、6.4_

## WebSocket 优化

- [ ] 7. 优化心跳（Heartbeat）机制
   - 添加心跳超时计时器，记录心跳发送时间
   - 收到 Heartbeat ACK 后重置超时计时器
   - 连续 2 次未收到 ACK 时主动关闭连接并触发重连
   - 心跳间隔限制最大为 30 秒
   - _需求：7.1、7.2、7.3、7.4、7.5、7.6_

- [ ] 8. 优化 Resume 机制
   - 收到 READY 时保存 `session_id` 和 gateway resume URL
   - 连接断开时优先尝试 Resume（op=6）
   - Resume 成功（RESUMED 事件）后继续使用当前 session
   - Resume 失败（op=9, d=false）时清除 session 重新 Identify
   - 处理服务端 Reconnect 指令（op=7）
   - 根据关闭码（4009、4900-4915）决定重连策略
   - _需求：8.1、8.2、8.3、8.4、8.5、8.6、8.7、8.8_

- [ ] 9. 实现事件异步处理
   - 修改 `handleMessage` 调用方式，使用 `.catch()` 异步执行
   - 同步更新 `lastSeq`，异步处理消息内容
   - 为每条消息创建独立的 `msg_seq` 管理上下文
   - 添加消息队列积压监控和处理（可选）
   - _需求：9.1、9.2、9.3、9.4、9.5_

## 代码清理

- [ ] 10. 移除群聊和频道场景代码
   - 删除 `gateway.ts` 中对 `GROUP_AT_MESSAGE_CREATE`、`AT_MESSAGE_CREATE`、`DIRECT_MESSAGE_CREATE` 的处理
   - 简化 intents 配置，仅保留 C2C 私聊相关权限
   - 清理 `api.ts` 中群聊和频道消息发送函数（如 `sendGroupMessage`、`sendChannelMessage`）
   - 更新类型定义，移除不再使用的群聊和频道消息类型
   - _需求：范围说明（仅支持 C2C 私聊场景）_
